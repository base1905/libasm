/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lpressed <lpressed@student.21.ru>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/11 19:09:20 by lpressed          #+#    #+#             */
/*   Updated: 2020/10/11 19:09:24 by lpressed         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
#include "libasm.h"
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

void test_ft_strlen()
{
	char	long_line[20000 + 1];
	int		i;

	printf("%s\n", "___TEST___ft_strlen___");
	
	//printf("NULL: %ld\n", ft_strlen(NULL));
	//printf("NULL: %ld\n", strlen(NULL));

	printf("empty_line: %ld\n", ft_strlen(""));
	printf("empty_line: %ld\n", strlen(""));

	printf("Hello_world: %ld\n", ft_strlen("Hello_world"));
	printf("Hello_world: %ld\n", strlen("Hello_world"));

	i = 0;
	while (i < 20000)
	{
		long_line[i] = 'a';
		i++;
	}
	long_line[20000] = '\0';
	printf("Long line: %ld\n", ft_strlen(long_line));
	printf("Long line: %ld\n", strlen(long_line));
	printf("%c %c %c %c\n", long_line[0], long_line[100], long_line[1000], long_line[10000]);
}

void test_ft_strcpy()
{
	char	long_line1[20000 + 1];
	char	long_line2[20000 + 1];
	char	long_s1[100];
	char	long_s2[100];
	int		i;

	printf("%s\n", "___TEST___ft_strcpy___");

	//printf("NULL: %s\n", ft_strcpy(NULL, NULL));
	//printf("NULL: %s\n", strcpy(NULL, NULL));

	//printf("NULL: %s\n", ft_strcpy(long_s1, NULL));
	//printf("NULL: %s\n", strcpy(long_s2, NULL));

	//printf("NULL: %s\n", ft_strcpy(NULL, "sss"));
	//printf("NULL: %s\n", strcpy(NULL, "sss"));

	printf("empty_line: %s\n", ft_strcpy(long_s1, ""));
	printf("empty_line: %s\n", strcpy(long_s2, ""));

	printf("Hello_world: %s\n", ft_strcpy(long_s1, "Hello_world"));
	printf("Hello_world: %s\n", strcpy(long_s2, "Hello_world"));

	i = 0;
	while (i < 20000)
	{
		long_line1[i] = 'a';
		i++;
	}
	long_line1[i] = '\0';

	printf("Long line: %s\n", ft_strcpy(long_line2, long_line1));
	bzero(long_line2, 20001);
	printf("Long line: %s\n", strcpy(long_line2, long_line1));
	printf("%s\n", "______________________________________");
}

void test_ft_strcmp()
{
	printf("%s\n", "___TEST___ft_strcmp___");

	//printf("NULL: %d\n", ft_strcmp(NULL, NULL));
	//printf("NULL: %d\n", strcmp(NULL, NULL));

	//printf("NULL: %d\n", ft_strcmp("sss", NULL));
	//printf("NULL: %d\n", strcmp("sss", NULL));

	//printf("NULL: %d\n", ft_strcmp(NULL, "sss"));
	//printf("NULL: %d\n", strcmp(NULL, "sss"));

	printf("empty_lines: %d\n", ft_strcmp("", ""));
	printf("empty_lines: %d\n", strcmp("", ""));

	printf("2_line: %d\n", ft_strcmp("Hello", ""));
	printf("2_line: %d\n", strcmp("Hello", ""));

	printf("1_line: %d\n", ft_strcmp("", "Hello"));
	printf("1_line: %d\n", strcmp("", "Hello"));

	printf("Hello_world: %d\n", ft_strcmp("Hello_world1", "Hello_world2"));
	printf("Hello_world: %d\n", strcmp("Hello_world1", "Hello_world2"));

	printf("line: %d\n", ft_strcmp("sdsd", "aaaaaaa"));
	printf("line: %d\n", strcmp("sdsd", "aaaaaaa"));
	printf("%s\n", "______________________________________");
}

void test_ft_write()
{
	int ft;
	int s;
	int fd;

	printf("%s\n", "___TEST___ft_write___");
	
	ft = ft_write(1, "TEST\n", 5);
	printf("ft_write: %d\n", ft);
	s = write(1, "TEST\n", 5);
	printf("write: %d\n", s);
	
	fd = open("write.txt", O_WRONLY | O_TRUNC);
	ft = write(fd, "TEST1\n", 6);
	printf("ft_write: %d\n", ft);
	close(fd);
	fd = open("ft_write.txt", O_WRONLY | O_TRUNC);
	s = write(fd, "TEST1\n", 6);
	printf("write: %d\n", s);
	close(fd);
	
	ft = ft_write(222, "test", 4);
	//ft = write(222, "test", 4);
	printf("fd = 222: %s\n", strerror(errno));
	printf("ret_val: %d\n", ft);
	printf("%s\n", "______________________________________");
}

void test_ft_read()
{
	int ft;
	int s;
	int fd;
	char buf1[100];
	char buf2[100];
	bzero(buf1, 100);
	bzero(buf2, 100);

	printf("%s\n", "___TEST___ft_read___");
	
	

	ft = ft_read(0, buf1, 100);
	printf("ft_read: %d\t", ft);
	printf("%s\n", buf1);
	s = read(0, buf2, 100);
	printf("read: %d\t", s);
	printf("%s\n", buf2);
	
	bzero(buf1, 100);
	bzero(buf2, 100);
	fd = open("write.txt", O_RDONLY);
	ft = ft_read(fd, buf1, 100);
	printf("ft_read: %d\t", ft);
	printf("%s\n", buf1);
	close(fd);
	fd = open("ft_write.txt", O_RDONLY);
	s = read(fd, buf2, 100);
	printf("read: %d\t", s);
	printf("%s\n", buf2);
	close(fd);
	
	bzero(buf1, 100);
	bzero(buf2, 100);
	ft = ft_read(222, buf1, 100);
	//ft = read(222, buf2, 100);
	printf("fd = 222: %s\n", strerror(errno));
	printf("ret_val: %d\n", ft);
	printf("%s\n", "______________________________________");
}

void test_ft_strdup()
{
	char *str1;
	char *str2;
	char long_line[20000 + 1];
	int	 i;

	//printf("NULL: %s\n", ft_strdup(NULL));
	//printf("NULL: %s\n", strdup(NULL));

	printf("%s\n", "___TEST___ft_strdup___");
	str1 = strdup("");
	printf("str1: %s\n", str1);
	str1[0] = 'F';
	printf("str1: %s\n", str1);
	free(str1);
	str2 = ft_strdup("");
	printf("str2: %s\n", str2);
	str2[0] = 'F';
	printf("str2: %s\n", str2);
	free(str2);

	str1 = strdup("HELLO_WOrlD");
	printf("str1: %s\n", str1);
	str1[0] = 'F';
	printf("str1: %s\n", str1);
	free(str1);
	str2 = ft_strdup("HELLO_WOrlD");
	printf("str2: %s\n", str2);
	str2[0] = 'F';
	printf("str2: %s\n", str2);
	free(str2);

	i = 0;
	while (i < 20000)
	{
		long_line[i] = 'a';
		i++;
	}
	long_line[20000] = '\0';
	str1 = strdup(long_line);
	printf("str1: %s\n", str1);
	str1[0] = 'F';
	printf("str1: %s\n", str1);
	free(str1);
	str2 = ft_strdup(long_line);
	printf("str2: %s\n", str2);
	str2[0] = 'F';
	printf("str2: %s\n", str2);
	free(str2);
	printf("%s\n", "______________________________________");
}

int	main()
{
	test_ft_strlen();
	test_ft_strcpy();
	test_ft_strcmp();
	test_ft_write();
	test_ft_read();
	test_ft_strdup();

	return (0);
}