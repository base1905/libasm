/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp_test.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cacharle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/08 03:08:03 by cacharle          #+#    #+#             */
/*   Updated: 2020/11/07 17:14:40 by charles          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libasm_test.h"

int strcmp_expected;
int strcmp_actual;

# define FT_STRCMP_EXPECT(s1, s2) do { \
	strcmp_expected = strcmp(s1, s2); \
	strcmp_actual = ft_strcmp(s1, s2); \
	if ((strcmp_expected < 0 && strcmp_actual < 0) || \
	    (strcmp_expected > 0 && strcmp_actual > 0) || \
	    (strcmp_expected == 0 && strcmp_actual == 0)) \
		print_ok(); \
	else \
		printf("KO: [COMPARE]: ft_strcmp.s: expected: %d got: %d with: "#s1", "#s2"\n", \
			   strcmp_expected, strcmp_actual); \
} while (0);

static
void ft_strcmp_test_segfault(void)
{
	TEST_ASM_FUNCTION(ft_strcmp("", ""));
	TEST_ASM_FUNCTION(ft_strcmp("bon", "bon"));
	TEST_ASM_FUNCTION(ft_strcmp("bonjour", "bonjour"));
	TEST_ASM_FUNCTION(ft_strcmp("abcdefghijasdf1324''klji//", "abcdefghijasdf1324''klji//"));
	TEST_ASM_FUNCTION(ft_strcmp("the\0hidden", "the\0hidden"));
	TEST_ASM_FUNCTION(ft_strcmp("Lorem ipsum dolor sit amet, consectetur adipiscing\
elit. Sed in malesuada purus. Etiam a scelerisque massa. Ut non euismod elit. Aliquam\
bibendum dolor mi, id fringilla tellus pulvinar eu. Fusce vel fermentum sem. Cras\
volutpat, eros eget rhoncus rhoncus, diam augue egestas dolor, vitae rutrum nisi\
felis sed purus. Mauris magna ex, mollis non suscipit eu, lacinia ac turpis. Phasellus\
ac tortor et lectus fermentum lobortis eu at mauris. Vestibulum sit amet posuere\
tortor, sit amet consequat amet.",
"Lorem ipsum dolor sit amet, consectetur adipiscing\
elit. Sed in malesuada purus. Etiam a scelerisque massa. Ut non euismod elit. Aliquam\
bibendum dolor mi, id fringilla tellus pulvinar eu. Fusce vel fermentum sem. Cras\
volutpat, eros eget rhoncus rhoncus, diam augue egestas dolor, vitae rutrum nisi\
felis sed purus. Mauris magna ex, mollis non suscipit eu, lacinia ac turpis. Phasellus\
ac tortor et lectus fermentum lobortis eu at mauris. Vestibulum sit amet posuere\
tortor, sit amet consequat amet."));
}

static
void ft_strcmp_test_compare(void)
{
	FT_STRCMP_EXPECT("", "");
	FT_STRCMP_EXPECT("bon", "");
	FT_STRCMP_EXPECT("bonjour", "");
	FT_STRCMP_EXPECT("asdklfjasdfj////asdf'''asdf3##", "");
	FT_STRCMP_EXPECT("the\0hidden", "");
	FT_STRCMP_EXPECT("Lorem ipsum dolor sit amet, consectetur adipiscing\
elit. Sed in malesuada purus. Etiam a scelerisque massa. Ut non euismod elit. Aliquam\
bibendum dolor mi, id fringilla tellus pulvinar eu. Fusce vel fermentum sem. Cras\
volutpat, eros eget rhoncus rhoncus, diam augue egestas dolor, vitae rutrum nisi\
felis sed purus. Mauris magna ex, mollis non suscipit eu, lacinia ac turpis. Phasellus\
ac tortor et lectus fermentum lobortis eu at mauris. Vestibulum sit amet posuere\
tortor, sit amet consequat amet.", "");
	FT_STRCMP_EXPECT("", "");
	FT_STRCMP_EXPECT("bon", "bon");
	FT_STRCMP_EXPECT("bonjour", "bonjour");
	FT_STRCMP_EXPECT("asdklfjasdfj////asdf'''asdf3##", "asdklfjasdfj////asdf'''asdf3##");
	FT_STRCMP_EXPECT("the\0hidden", "the\0hidden");
	FT_STRCMP_EXPECT("Lorem ipsum dolor sit amet, consectetur adipiscing\
elit. Sed in malesuada purus. Etiam a scelerisque massa. Ut non euismod elit. Aliquam\
bibendum dolor mi, id fringilla tellus pulvinar eu. Fusce vel fermentum sem. Cras\
volutpat, eros eget rhoncus rhoncus, diam augue egestas dolor, vitae rutrum nisi\
felis sed purus. Mauris magna ex, mollis non suscipit eu, lacinia ac turpis. Phasellus\
ac tortor et lectus fermentum lobortis eu at mauris. Vestibulum sit amet posuere\
tortor, sit amet consequat amet.",
"Lorem ipsum dolor sit amet, consectetur adipiscing\
elit. Sed in malesuada purus. Etiam a scelerisque massa. Ut non euismod elit. Aliquam\
bibendum dolor mi, id fringilla tellus pulvinar eu. Fusce vel fermentum sem. Cras\
volutpat, eros eget rhoncus rhoncus, diam augue egestas dolor, vitae rutrum nisi\
felis sed purus. Mauris magna ex, mollis non suscipit eu, lacinia ac turpis. Phasellus\
ac tortor et lectus fermentum lobortis eu at mauris. Vestibulum sit amet posuere\
tortor, sit amet consequat amet.");

	FT_STRCMP_EXPECT("", "asdf");
	FT_STRCMP_EXPECT("bon", "bo");
	FT_STRCMP_EXPECT("bonjour", "onjour");
	FT_STRCMP_EXPECT("asdklfjasdfj////asdf'''asdf3##", "asdklfjasdfj////asdf'''asdf3##");
	FT_STRCMP_EXPECT("the\0hidden", "thehidden");
	FT_STRCMP_EXPECT("Lorem ipsum dolor st amet, consectetur adipiscing", "Lodsfsdfasdf");

	FT_STRCMP_EXPECT("\x01", "\x01");
	FT_STRCMP_EXPECT("\x02", "\x01");
	FT_STRCMP_EXPECT("\x01", "\x02");
	FT_STRCMP_EXPECT("\xff", "\xff");
	FT_STRCMP_EXPECT("\xfe", "\xff");
	FT_STRCMP_EXPECT("\xff", "\xfe");

	FT_STRCMP_EXPECT("\x01\x01", "\x01");
	FT_STRCMP_EXPECT("\x01\x02", "\x01");
	FT_STRCMP_EXPECT("\x02\x01", "\x02");
	FT_STRCMP_EXPECT("\xff\xff", "\xff");
	FT_STRCMP_EXPECT("\xff\xfe", "\xff");
	FT_STRCMP_EXPECT("\xfe\xff", "\xfe");

	FT_STRCMP_EXPECT("\x01", "\x01\x01");
	FT_STRCMP_EXPECT("\x01", "\x01\x02");
	FT_STRCMP_EXPECT("\x02", "\x02\x01");
	FT_STRCMP_EXPECT("\xff", "\xff\xff");
	FT_STRCMP_EXPECT("\xff", "\xff\xfe");
	FT_STRCMP_EXPECT("\xfe", "\xfe\xff");
}

void ft_strcmp_test(void)
{
	test_name = "ft_strcmp.s";
	signaled_suite = false;
	ft_strcmp_test_segfault();
	if (!signaled_suite)
		ft_strcmp_test_compare();
}
